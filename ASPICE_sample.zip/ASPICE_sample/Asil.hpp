#ifndef ASIL_H
#define ASIL_H

class Asil {

public:
    Asil();
    ~Asil();

};

#endif // Asil_H