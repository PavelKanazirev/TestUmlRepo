#ifndef QMTEST_H
#define QMTEST_H

#include "../Qm.hpp"

class QmTest : public Qm {

public:
 QmTest();
 ~QmTest();

 bool run();
};

#endif // QMTEST_H
