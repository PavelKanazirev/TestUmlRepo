#include <iostream>

#include "AsilTest.hpp"

AsilTest::AsilTest(){ std::cout <<__PRETTY_FUNCTION__<<std::endl;};
AsilTest::~AsilTest(){ std::cout <<__PRETTY_FUNCTION__<<std::endl;};


 bool AsilTest::run()
 {
    bool result = false;
    std::cout <<__PRETTY_FUNCTION__<<std::endl;

    return result;
 }
