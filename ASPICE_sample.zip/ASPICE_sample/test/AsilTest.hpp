#ifndef ASILTEST_H
#define ASILTEST_H

#include "../Asil.hpp"

class AsilTest : public Asil {

public:
 AsilTest();
 ~AsilTest();

bool run();

};

#endif // ASILTEST_H
