#include <iostream>

#include "Asil.hpp"

Asil::Asil(){ std::cout <<__PRETTY_FUNCTION__<<std::endl;};
Asil::~Asil(){ std::cout <<__PRETTY_FUNCTION__<<std::endl;};
