#ifndef QM_H
#define QM_H

class Qm {

public:
 Qm();
 ~Qm();

};

#endif // QM_H
