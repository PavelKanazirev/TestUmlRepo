#include <iostream>
#include <stdlib.h>
#include <cstdlib>

#include "Qm.hpp"
#include "Asil.hpp"

int main(int argc, char *argv[])
{
    std::cout <<"Hola, Globo!"<<std::endl;

    system("pause");

    return 0;
}