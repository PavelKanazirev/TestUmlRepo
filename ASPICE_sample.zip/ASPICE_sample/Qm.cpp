#include <iostream>

#include "Qm.hpp"

Qm::Qm(){ std::cout <<__PRETTY_FUNCTION__<<std::endl;};
Qm::~Qm(){ std::cout <<__PRETTY_FUNCTION__<<std::endl;};
